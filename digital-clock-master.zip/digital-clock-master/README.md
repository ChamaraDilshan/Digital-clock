# CO222: Programming Methodology (Project 1)

## Description: 
C implementation of a digital clock that prints the current time, and date on the Linux terminal. If a color is given as an argument to the program, the program must be able to print a colored output.

*Output.pdf shows the expected ouput from the program.* 

